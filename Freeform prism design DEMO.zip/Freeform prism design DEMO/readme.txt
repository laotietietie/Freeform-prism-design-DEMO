1.run Newprismdesigh.exe  in compatibility mode
2.set the parameters of the initial flat prism
3.choose the "fix angle" buttom
4.click freeform button and wait until the "work done" dialog box pops up
5.set the iterations P ,then click "compute and show" button

the point cloud datas of freeform prism will store in "outputall.txt"
the furface fit resulte will store in "output_fit_fig1.txt" and "output_fit_fig2.txt"